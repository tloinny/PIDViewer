# SpeedyStepper - Arduino Library


This library is used to control one or more stepper motors.  The motors are accelerated and decelerated as they travel to their destination.  The library has been optimized for speed.


## Documentation:
For documentation and a hookup guide, go to:

​    https://github.com/Stan-Reifel/SpeedyStepper

## License:
Copyright (c) 2018 S. Reifel & Co.   -   Licensed under the MIT license.
